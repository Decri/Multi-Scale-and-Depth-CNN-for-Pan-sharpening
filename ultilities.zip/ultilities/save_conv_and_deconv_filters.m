function [] = save_conv_and_deconv_filters(class_of_weights,iters,model,savepath)
%% settings
weights = ['snapshots\',class_of_weights,'_iter_',num2str(iters),'.caffemodel'];
%% load model using mat_caffe
net = caffe.Net(model,weights,'test');
count = 0;
%% reshape parameters
for idx = 1 : length(net.layer_vec)
    layername = net.layer_names(idx);layername = layername{1};
    layercontainment = net.layers(layername).params;
    isconvordeconv = (~isempty(strfind(layername,'conv')))&&(size(layercontainment,1));
    if isconvordeconv == 1
    count = count + 1;
    filters = net.layers(layername).params(1).get_data();
    weight{count} = filters;
    bias{count} = net.layers(layername).params(2).get_data();
    end
end
%% save parameters
save(savepath,'weight','bias');
end

function [spcc] = spCC_noref(sta,fused)

[M,N,~] = size(sta);
[m,n,bs] = size(fused);

assert(M == m && N == n,'Ӱ��������Ӧ���');
spcc = zeros(1,bs);

w = [-1 -1 -1;-1 8 -1;-1 -1 -1];
for k = 1 : bs
    A = sta;
    B = RSgenerate(fused(:,:,k),0,0);
    AH = conv2(A,w,'same');
    BH = conv2(B,w,'same');
    cc = corrcoef(AH,BH);spcc(k) = cc(1,2);
end

spcc = mean(spcc);
end
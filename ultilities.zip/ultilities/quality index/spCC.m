function [spcc] = spCC(sta,fused)

[M,N,bs1] = size(sta);
[m,n,bs2] = size(fused);

assert(M == m && N == n,'Ӱ��������Ӧ���');
assert(bs1 == bs2,'Ӱ�񲨶���Ӧ���');
spcc = zeros(1,bs1);

w = [-1 -1 -1;-1 8 -1;-1 -1 -1];
for k = 1 : bs1
    A = sta(:,:,k);
    B = fused(:,:,k);
    
    AH = conv2(A,w,'same');
    BH = conv2(B,w,'same');
    
    cc = corrcoef(AH,BH);spcc(k) = cc(1,2);
end

spcc = mean(spcc);
end